﻿# week3 plugin 예시

이 폴더는 실습 4를 위해 만든 묶음 배포 구조 예시다.

## 포함 요소

- `plugin.json`: plugin 메타데이터 예시
- `.mcp.json`: MCP 서버 연결 설정 예시
- `skills/doc-summary/SKILL.md`: 문서 요약용 skill 예시

## 핵심 의미

- plugin은 MCP 서버 설정, skill, 에이전트 작업 지침을 한 번에 묶어 배포하는 단위로 이해하면 된다.
- 실제 제품마다 세부 포맷은 다를 수 있으므로, 이 예시는 구조 이해를 위한 수업용 샘플이다.
