﻿# Week 3 Copilot CLI Plugin Example

이 디렉토리는 실습 5 제출물 중 `Copilot CLI plugin 디렉토리 1개`를 충족하기 위한 예시 구조다.

## 포함 요소

- `plugin.json`: plugin 메타데이터 예시
- `.mcp.json`: 프로젝트에서 사용할 최소 MCP 서버 연결 설정
- `skills/doc-summary/SKILL.md`: 문서 요약용 skill 예시

## 의도

- plugin은 skill, MCP 설정, 작업 규칙을 함께 묶어 재사용 가능한 작업 패키지로 배포하는 단위라는 점을 보여준다.
- 이 예시는 수업용 구조 샘플이며, 실제 제품별 세부 포맷은 다를 수 있다.
